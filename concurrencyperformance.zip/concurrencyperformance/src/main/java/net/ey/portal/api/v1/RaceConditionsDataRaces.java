package net.ey.portal.api.v1;/*
 * Copyright (c) 2019-2023. Michael Pogrebinsky - Top Developer Academy
 * https://topdeveloperacademy.com
 * All rights reserved
 */

/**
 * Race Conditions & Data Races
 * https://www.udemy.com/java-multithreading-concurrency-performance-optimization
 */
public class RaceConditionsDataRaces {

    public static void main(String[] args) {

        SharedClass sharedClass = new SharedClass();

        Thread incrementThread = new Thread(() -> {
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                sharedClass.increment();
            }
        });

        Thread dataRaceThread = new Thread(() -> {
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                sharedClass.checkForDataRace();
            }

        });
        incrementThread.setName("incrementThread");
        incrementThread.start();
        dataRaceThread.setName("dataRaceThread");
        dataRaceThread.start();
    }

    public static class SharedClass {
        private volatile int x = 0;
        private volatile int y = 0;

        public   void  increment() {
            x++;
            y++;
        }

        public  void checkForDataRace() {
            if (y > x) {
                System.out.println("y > x - Data Race is detected");
            }
        }
    }
}
